# IOS-MCN-RAN

This version of the IOS-MCN-RAN comes with a containerized way of deploying Radio Access Network. Different ways of deployment can be found in cicd folder, configure the respective configuration files required for your deployent present in the conf folder. Deploy your own image or the image built by IOS-MCN-RAN by configuring the .env file present in the respective flavors of deployment in the cicd folder.

The deployment is as easy as modifying the .env file configuration file and running docker-compose up -d. </br>
For example:
```
vi cicd/5g_sa_rfsim/.env
vi conf/gnb-cucp.sa.f1-e1.iisc.conf
cd cdcd/5g_sa_rfsim
docker-compose up -d
```

The source code for the RAN is present in [IOS-MCN-RAN openairinterface5g] (https://github.com/ios-mcn-ran/openairinterface5g)