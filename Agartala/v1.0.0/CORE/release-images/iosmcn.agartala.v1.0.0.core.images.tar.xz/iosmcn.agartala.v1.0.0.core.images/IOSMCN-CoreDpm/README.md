# IOS-MCN-CORE

IOSMCN-CoreDpm provides a low-overhead way to bring up a
Kubernetes cluster, deploy a 5G version of ios-mcn-core on that
cluster, and then connect that Core to either an emulated 5G RAN
or a network of physical gNBs. 

To download IOSMCN-CoreDpm (and all the submodules it depends on),
type:

```
$ git clone --recursive https://github.com/ios-mcn-core/IOSMCN-CoreDpm.git
```

Taking a quick look at your ``IOSMCN-CoreDpm`` directory, you will
find the following.

1. The ``deps`` directory contains Ansible deployment
   specifications for all the ios-mcn-core subsystems. Each of these
   subdirectories (e.g., ``deps/5gc``) is self-contained, but
   the Makefile in the main IOSMCN-CoreDpm directory imports the
   per-subsystem Makefiles, meaning all the steps required
   to install ios-mcn-core can be (and typically should be) managed from
   this main directory.

2. File ``vars/main.yml`` defines all the Ansible variables you will
   potentially need to modify to specify your deployment scenario.
   This file is the union of all the per-component ``var/main.yml``
   files you find in the corresponding ``deps`` directory. This
    top-level variable file overrides the per-component files, so
   you will not need to modify the latter. The ``vars`` directory
   contains several variants of ``main.yml``, each tailored for a
   different deployment scenario, with the default ``main.yml``
   supporting the Quick Start deployment described below.

3. File ``hosts.ini`` specifies the set of servers (physical or
   virtual) that Ansible targets with various playbooks. The
   default version included with IOSMCN-CoreDpm is simplified to run
   everything on a single server (the one you've cloned the
   repo onto). Example multi-node inventories are commented out.

IOSMCN-CoreDpm assumes Ansible is installed.Then, once you edit ``hosts.ini`` to
match your local details, type the following to verify the setup:

```
$ make iosmcn-pingall
```

## Quick Start

Edit ``vars/main.yml`` to reflect your local scenario. For
the Quick Start deployment, this means setting variable
``data_iface`` to your server's network interface. Note there are
**two** lines that define this variable, one in the ``core`` section
and one in the ``gnbsim`` section. You also need to set the
IP address of the AMF (in the ``core`` section) to your servers's
IP address.

You are now ready to install a one-node Kubernetes cluster. Type:

```
$ make iosmcn-k8s-install
```

Once Kubernetes is running (which you can verify with ``kubectl``),
you are ready to intall the 5G version of SD-Core. Type:

```
$ make iosmcn-5gc-install
```

Once the Core is running (which you can verify by using ``kubectl`` to
check the ``iosmcn`` name space), you are ready to emulate a RAN
workload. Type:

When you are ready to tear down your Quick Start deployment of iosmcn-core,
execute the following commands:

```
$ make iosmcn-5gc-uninstall
$ make iosmcn-k8s-uninstall
```

Or alternatively:

```
$ make iosmcn-uninstall
```

