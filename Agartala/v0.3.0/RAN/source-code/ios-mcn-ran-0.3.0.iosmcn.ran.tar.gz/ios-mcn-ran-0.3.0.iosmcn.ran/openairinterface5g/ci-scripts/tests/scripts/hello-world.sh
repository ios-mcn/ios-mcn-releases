#!/bin/bash

set -x
echo hello, world
