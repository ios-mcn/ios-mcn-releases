# Developers Guide
This section provides reference links to the core components and related projects used in the RAN deployment. These resources are intended for developers who want to understand, modify, or extend the system.

openairinterface5g(RAN): [link](https://github.com/ios-mcn-ran/openairinterface5g/tree/iosmcnmaster/doc)<br>
o1-adapter(O1): [link](https://github.com/ios-mcn-ran/o1-adapter/blob/iosmcnmaster/README.md)<br>
flexric(E2): [link](https://github.com/ios-mcn-ran/flexric)<br>
phy(Fronthaul): [link](https://docs.o-ran-sc.org/projects/o-ran-sc-o-du-phy/en/latest/Architecture-Overview_fh.html)<br>
uhd(Fronthaul): [link](https://uhd.readthedocs.io/en/latest/page_uhd.html)<br>

## Related Documentation
- [Installation Guide](../README.md)
- [User Guide](./README.md)
- [Troubleshooting](./Troubleshooting.md)
