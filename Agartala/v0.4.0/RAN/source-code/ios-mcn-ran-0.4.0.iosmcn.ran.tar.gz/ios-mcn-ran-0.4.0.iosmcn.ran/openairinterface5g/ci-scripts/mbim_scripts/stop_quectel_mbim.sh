set -x

sudo mbimcli -p -d /dev/cdc-wdm0 --set-radio-state=off
