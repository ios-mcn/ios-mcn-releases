#!/bin/bash

echo $@
false
