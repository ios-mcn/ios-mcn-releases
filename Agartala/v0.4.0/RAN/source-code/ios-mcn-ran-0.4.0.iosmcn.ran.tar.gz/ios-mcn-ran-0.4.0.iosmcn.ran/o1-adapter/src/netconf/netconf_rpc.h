#include <libyang/libyang.h>
#include <sysrepo.h>

int netconf_rpcs_init(void);